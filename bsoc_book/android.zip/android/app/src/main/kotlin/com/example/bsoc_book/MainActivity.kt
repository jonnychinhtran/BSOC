package com.example.bsoc_book

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
